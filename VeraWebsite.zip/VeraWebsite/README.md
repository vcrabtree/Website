# Website

This website was created as a personal website intended to be used as a portfolio of my work and acheivements. This website was programmed using HTML/CSS with a Bootstrap 4 framework.

## Pages

- **Home**: Consists of background information on me as well as a form that allows an individual to send me an email (using webiste called Formspree)
- **Projects**: Discusses some of the major programs I have implemented, includes a brief description as well as a link to the Github repository
- **Resume**: Links to a PDF of my current resume
